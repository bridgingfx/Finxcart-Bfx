{{-- <ul class="row list-unstyled products-group no-gutters mx-3 d-flex justify-content-center my-5">
    @foreach ($latestProductsList as $pdtkey => $pdtval)
        <li class="col-sm-6 col-6 col-wd-3 p-1 col-xl-2 col-lg-3 col-md-4 product-item ">
            <div class="product-item__outer h-100 w-100">
                <div class="product-item__inner px-xl-4 p-3">
                    <div class="product-item__body pb-xl-2">
                        <h5 class="mb-1 product-item__title">
                            <span class="loop-product-categories"><a href="https://electro.madrasthemes.com/product-category/tv-audio/audio-speakers/" rel="tag">{{ $pdtval->subCategory->name }}</a></span>
                            <a href="{{route('product',$pdtval->slug)}}"
                               class="text-blue font-weight-bold">{{ $pdtval->name }}</a>
                        </h5>

                         <div class="mb-2 img-container">
                            <a href="{{route('product',$pdtval->slug)}}" class="d-block text-center">
                                <img class="img-fluid" src="{{ asset('storage/product/thumbnail/'.$pdtval->thumbnail) }}" alt="{{ $pdtval->name }}">
                            </a>
                        </div>

                        <div class="flex-center-between mb-1">
                            <div class="prodcut-price">
                                <div class="text-gray-100">${{ number_format($pdtval->unit_price, 2) }}</div>
                            </div>
                        </div>
                    </div>

                    <div class="product-item__footer">
                        <div class="border-top pt-2 flex-center-between flex-wrap">
                            <div class="d-xl-block prodcut-add-cart float-right">
                                <button type="button" data-toggle="tooltip" title="Add To Cart"
                                        class="btn-add-to-cart btn btn-2xs btn-theme1 cart-icons add-to-cart"
                                        data-product-id="{{ base64_encode($pdtval->id) }}"
                                        data-product-price="{{ $pdtval->unit_price }}"
                                        data-product-name="{{ $pdtval->name }}"
                                        data-token="{{ csrf_token() }}">
                                    <i class="fas fa-shopping-cart" title="Add to cart"></i>
                                </button>
                                <button type="button" class="add-to-wishlist btn btn-2xs btn-theme2 cart-icons"
                                        data-product-id="{{ $pdtval->id }}" data-toggle="tooltip"
                                        title="Add to Wishlist">
                                    <i class="fas fa-heart"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </li>
    @endforeach
</ul> --}}

 <div class="container mt-5">
     <ul class="row list-unstyled products-group no-gutters">
        @foreach ($latestProductsList as $pdtkey => $pdtval)
            <li class="col-6 col-md-4 col-xl product-item">
                <div class="product-item__outer h-100 w-100">
                    <div class="product-item__inner px-xl-4 p-3">
                        <div class="product-item__body pb-xl-2">
                            <div class="mb-2"><a href="{{route('product',$pdtval->slug)}}" class="font-size-12 text-gray-5">{{ $pdtval->subCategory->name }}</a></div>
                            <h5 class="mb-1 product-item__title"><a href="{{route('product',$pdtval->slug)}}" class="text-blue font-weight-bold">{{ $pdtval->name }}</a></h5>
                            <div class="mb-2 ">
                                <a href="{{route('product',$pdtval->slug)}}" class="d-block text-center"><img class="img-fluid img-container" src="{{ asset('storage/product/thumbnail/'.$pdtval->thumbnail) }}" alt="{{ $pdtval->name }}"></a>
                            </div>
                            <div class="flex-center-between mb-1">
                                <div class="prodcut-price">
                                    <div class="text-gray-100">${{ number_format($pdtval->unit_price, 2) }}</div>
                                </div>
                                <div class=" d-xl-block prodcut-add-cart">
                                    <a href="" class="btn-add-cart btn-primary transition-3d-hover"><i class="ec ec-add-to-cart"></i></a>
                                   {{-- <form class="addToCartDynamicForm" method="POST">
                                <input type="hidden" name="id" value="{{ $pdtval->id }}">
                                <input type="hidden" name="radio" value="[]">
                                <input type="hidden" name="quantity" value="1">
                                <input type="hidden" name="color" value="1">
                                <input type="hidden" class="product-generated-variation-code" name="product_variation_code" data-product-id="{{ $pdtval->id }}">

                                <input type="hidden" class="product-exist-in-cart-list" name="variant_key" value="0">
                                <button type="button" class="product-add-to-cart-button" data-update="Added to Cart">
                                    Add to Cart
                                </button>
                            </form> --}}
                                </div>
                            </div>
                        </div>
                        <div class="product-item__footer">
                            <div class="border-top pt-2 text-center">

                                <a href="" class="text-gray-6 font-size-13"><i class="ec ec-favorites mr-1 font-size-15"></i> Wishlist</a>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
        @endforeach

    </ul>
</div>





